library(AER)
library(dplyr)
library(geepack)
library(survey)
library(testthat)

set.seed(123)
test_check("Zelig")
